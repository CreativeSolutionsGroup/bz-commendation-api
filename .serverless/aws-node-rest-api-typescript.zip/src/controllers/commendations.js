"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.del = exports.create = exports.update = exports.get = exports.all = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
aws_sdk_1.default.config.update({ region: "us-east-2" });
const documentClient = new aws_sdk_1.default.DynamoDB.DocumentClient({ apiVersion: "2012-08-10" });
const all = async (req, res) => {
};
exports.all = all;
const get = async (req, res) => {
    const clientId = req.params.id;
    try {
        let commendation = await documentClient.get({
            TableName: "bz_commendation",
            Key: {
                email: clientId
            }
        }).promise();
        return res.json(commendation.Item);
    }
    catch (e) {
        console.log(e);
    }
};
exports.get = get;
const update = async (req, res) => {
};
exports.update = update;
const create = async (req, res) => {
    const newCommendation = req.body;
    newCommendation.date = Date.now().toString();
    try {
        await documentClient.put({
            TableName: "bz_commendation",
            Item: newCommendation
        }).promise();
        return res.json("Finished.");
    }
    catch (e) {
        console.log(e);
    }
};
exports.create = create;
const del = async (req, res) => {
    const id = req.params.id;
    try {
        const dcRes = await documentClient.delete({
            TableName: "bz_commendation",
            Key: {
                "email": id
            }
        }).promise();
        return res.json(dcRes.ItemCollectionMetrics);
    }
    catch (e) {
        console.log(e);
    }
};
exports.del = del;
//# sourceMappingURL=commendations.js.map