"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.del = exports.create = exports.update = exports.get = exports.all = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const uuid_1 = require("uuid");
aws_sdk_1.default.config.update({ region: "us-east-2" });
const documentClient = new aws_sdk_1.default.DynamoDB.DocumentClient();
const all = async (req, res) => {
};
exports.all = all;
const get = async (req, res) => {
    const clientId = req.params.id;
    try {
        let commendation = await documentClient.get({
            TableName: "bz_commendation",
            Key: {
                toEmail: clientId
            }
        }).promise();
        return res.json(commendation.Item);
    }
    catch (e) {
        return res.json({ response: "Failed", reason: e });
    }
};
exports.get = get;
const update = async (req, res) => {
};
exports.update = update;
const create = async (req, res) => {
    const newCommendation = req.body;
    newCommendation._id = uuid_1.v4();
    newCommendation.date = Date.now().toString();
    try {
        await documentClient.put({
            TableName: "bz_commendation",
            Item: newCommendation
        }).promise();
        return res.json("Finished.");
    }
    catch (e) {
        return res.json({ response: "Failed", reason: e });
    }
};
exports.create = create;
const del = async (req, res) => {
    const id = req.params.id;
    try {
        const dcRes = await documentClient.delete({
            TableName: "bz_commendation",
            Key: {
                "toEmail": id
            }
        }).promise();
        return res.json(dcRes.ItemCollectionMetrics);
    }
    catch (e) {
        return res.json({ response: "Failed", reason: e });
    }
};
exports.del = del;
//# sourceMappingURL=commendations.js.map