"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const dotenv_1 = __importDefault(require("dotenv"));
const commendations_1 = __importDefault(require("./routers/commendations"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const body_parser_1 = __importDefault(require("body-parser"));
dotenv_1.default.config();
const port = process.env.PORT;
const app = express_1.default();
app.use(body_parser_1.default.json());
commendations_1.default(app);
app.listen(port, () => {
    console.log(`Server started on port ${port} 🚀🚀🚀`);
});
module.exports.handler = serverless_http_1.default(app);
//# sourceMappingURL=app.js.map