"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const commendations_1 = require("../controllers/commendations");
const commendationRoutes = (app) => {
    console.log(`Registering commendation routes.`);
    app.route(`/commendation`)
        .get(commendations_1.all)
        .put(commendations_1.update)
        .post(commendations_1.create);
    app.route(`/commendation/:id`)
        .get(commendations_1.get)
        .delete(commendations_1.del);
};
exports.default = commendationRoutes;
//# sourceMappingURL=commendations.js.map